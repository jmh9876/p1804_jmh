from distutils.core import setup
setup(name="jmh", version="1.0", description="this is test mod", author="jmh", py_modules=['suba.aa', 'suba.bb', 'subb.cc', 'subb.dd'])
