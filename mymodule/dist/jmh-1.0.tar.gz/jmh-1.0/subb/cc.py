def CC:
    print('===cc===')
